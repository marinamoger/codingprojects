//Author: Marina Moger
/* This program allows users to log in to a database of spells and spellbooks.
 * Users can search for spells by name or effect, and can choose to print the 
 * spells to the terminal or a text file. Available spells are restricted 
 * depending on the user's status.
 */
#include "catalog.hpp"

//Function to create a dynamic array of spells
spell* create_spells(int size){
    return new spell[size];
}

/* 
 * Function to read a single spells data from the file. s represents a single 
 * spell structure of type spell.
 */
spell read_spell_data(std::ifstream& file){
    spell s;
    file >> s.name >> s.success_rate >> s.effect;
    return s;
}

//Function to create a dynamic array of spellbooks 
spellbook* create_spellbooks(int size){
    return new spellbook[size];
}

/* 
 * Function to read a single spellbooks data from a file. sb represents a 
 * single spellbook structure of type spellbook.
 */
spellbook read_spellbook_data(std::ifstream& file){
    spellbook sb;
    file >> sb.title >> sb.author >> sb.num_pages >> sb.edition >> sb.num_spells;
    sb.spells = create_spells(sb.num_spells);

    float total_success_rate = 0;
    for (int i = 0; i < sb.num_spells; i++){
        sb.spells[i] = read_spell_data(file);
        total_success_rate += sb.spells[i].success_rate;
    }
    sb.avg_success_rate = total_success_rate / sb.num_spells;
    return sb;
}

//Function to delete dynamic array of spells
void delete_spells(spell*& spells){
    delete[] spells;
    spells = nullptr;
}

//Function to delete a dynamic array of spellbooks and their spells
void delete_spellbooks(spellbook*& spellbooks, int size){
    for (int i = 0; i < size; i++){
        delete_spells(spellbooks[i].spells);
    }
    delete[] spellbooks;
    spellbooks = nullptr;
}

//Function to read info about different wizards from file
wizard* read_wizards(const std::string& filename, int& wizard_count){
    std::ifstream file(filename);
    if (!file) {
        std::cerr << "Error: could not open file " << filename << "."<< "\n";
        exit(1);
    }
    file >> wizard_count;
    wizard* wizards = new wizard[wizard_count];

        for (int i = 0; i < wizard_count; i++){
            file >> wizards[i].name >> wizards[i].id >> wizards[i].password \
            >> wizards[i].position_title >> wizards[i].beard_length;
        }

    file.close();
    return wizards;
}

//Function to read spellbooks from a file
spellbook* read_spellbooks(const std::string& filename, int& spellbook_count){
    std::ifstream file(filename);
    if (!file){
        std::cerr << "Error: could not open file " << filename << "." << "\n";
        exit(1);
    }
    file >> spellbook_count;
    spellbook* spellbooks = create_spellbooks(spellbook_count);

        for (int i = 0; i < spellbook_count; i++){
            spellbooks[i] = read_spellbook_data(file);
        }
    file.close();
    return spellbooks;
}

// Login function
wizard* login(wizard* wizards, int wizard_count) {
   int attempts = 0; // Initialize attempts

    // Loop for a maximum of 3 attempts
    while (attempts < 3) {
        std::string id_str, password; // Store ID as a string to validate input

        // Prompt for ID and validate input as a positive integer
        std::cout << "Enter your ID: ";
        std::cin >> id_str;
        
        // Check if the entered ID is a valid integer
        bool valid_id = true;
        for (char c : id_str) {
            if (!isdigit(c)) {
                valid_id = false;
                break;
            }
        }

        if (!valid_id) {
            std::cout << "Invalid ID. Please enter a positive integer.\n";
            attempts++;
            continue; // Go to the next attempt
        }

        // Convert the valid ID string to an integer
        int id = std::stoi(id_str);

        // Prompt for the password
        std::cout << "Enter your password: ";
        std::cin >> password;

        // Check credentials
        for (int i = 0; i < wizard_count; ++i) {
            if (wizards[i].id == id && wizards[i].password == password) {
                // Successful login
                std::cout << "Welcome " << wizards[i].name << "!\n"
                          << "ID: " << wizards[i].id << "\n"
                          << "Status: " << wizards[i].position_title << "\n"
                          << "Beard Length: " << wizards[i].beard_length << "\n";
                return &wizards[i]; // Return the logged-in wizard
            }
        }

        // If credentials are incorrect
        std::cout << "Invalid login. Try again.\n";
        attempts++; // Increment attempts
    }

    // If all attempts are used, exit the program
    std::cerr << "Too many failed attempts. Exiting.\n";
    exit(1);
}

// Function to check if a spell should be hidden based on the wizard's status
bool is_spell_hidden(const spell& s, const wizard* user) {
    // Hide "death" and "poison" spells if the wizard is a student
    if (user->position_title == "Student" && 
        (s.effect == "poison" || s.effect == "death")) {
        return true;
    }
    return false;
}

// Display all spellbooks and spells
void display_all_spellbooks(spellbook* spellbooks, int spellbook_count, 
wizard* user) {
    for (int i = 0; i < spellbook_count; ++i) {
        std::cout << "Title: " << spellbooks[i].title << "\n"
                  << "Author: " << spellbooks[i].author << "\n"
                  << "Average Success Rate: " << spellbooks[i].avg_success_rate 
                  << "\n"
                  << "Spells:\n";

        for (int j = 0; j < spellbooks[i].num_spells; ++j) {
            if (is_spell_hidden(spellbooks[i].spells[j], user)) continue;
            std::cout << "- " << spellbooks[i].spells[j].name << "\n";
        }
    }
}
/* Function to search for spellbooks by name, & print them to terminal or 
 * text file depending on the user's input.
 */
void search_spellbook_by_name(spellbook* spellbooks, int spellbook_count) {
    std::string search_name;
    std::cout << "Enter the spellbook name: ";
    std::cin >> search_name;

    bool found = false;

    for (int i = 0; i < spellbook_count; ++i) {
        if (spellbooks[i].title == search_name) {
            found = true;
            int display_option;

            // Ask user how to display the information
            while (true) {
                std::cout << "How would you like to display the information?\n";
                std::cout << "1. Print to terminal\n";
                std::cout << "2. Write to an output file\n";
                std::cout << "Your choice: ";
                std::cin >> display_option;

                if (display_option == 1) {
                    std::cout << "Spellbook: " << spellbooks[i].title << "\n";
                    std::cout << "Author: " << spellbooks[i].author << "\n";
                    std::cout << "Pages: " << spellbooks[i].num_pages << "\n";
                    std::cout << "Edition: " << spellbooks[i].edition << "\n";
                    std::cout << "Spells:\n";
                    for (int j = 0; j < spellbooks[i].num_spells; ++j) {
                        std::cout << "- " << spellbooks[i].spells[j].name 
                                  << " (" << spellbooks[i].spells[j].effect 
                                  << ")\n";
                    }
                    break;
                } else if (display_option == 2) {
                    std::string filename;
                    std::cout << "Enter the output filename: ";
                    std::cin >> filename;

                    std::ofstream outfile(filename, std::ios::app);
                    outfile << "Spellbook: " << spellbooks[i].title << "\n";
                    outfile << "Author: " << spellbooks[i].author << "\n";
                    outfile << "Pages: " << spellbooks[i].num_pages << "\n";
                    outfile << "Edition: " << spellbooks[i].edition << "\n";
                    outfile << "Spells:\n";
                    for (int j = 0; j < spellbooks[i].num_spells; ++j) {
                        outfile << "- " << spellbooks[i].spells[j].name 
                                << " (" << spellbooks[i].spells[j].effect 
                                << ")\n";
                    }
                    outfile.close();
                    std::cout << "Information written to " << filename << "\n";
                    break;
                } else {
                    std::cout << "Invalid option. Please enter 1 or 2.\n";
                }
            }
            break;
        }
    }

    if (!found) {
        std::cout << "Error: Spellbook not found.\n";
    }
}

/* Function to search for spellbooks by effect, & print them to terminal or 
 * text file depending on the user's input.
 */
void search_spells_by_effect(spellbook* spellbooks, int spellbook_count, 
wizard* user) {
    std::string valid_effects[] = {"fire", "bubble", "memory_loss", "death", 
    "poison"};
    std::string effect;
    bool valid = false;

    while (!valid) {
        std::cout << "Enter the spell effect: ";
        std::cin >> effect;

        
        for (const auto& valid_effect : valid_effects) {
            if (effect == valid_effect) {
                valid = true;
                break;
            }
        }

        // Check if students can see this effect
        if (user->position_title == "Student" && 
            (effect == "poison" || effect == "death")) {
            std::cout 
            << "Students are not allowed to view spells with this effect.\n";
            valid = false;
        }

        if (!valid) {
            std::cout << "Invalid spell effect. Please try again.\n";
        }
    }

    // Display options to the user
    int display_option;
    while (true) {
        std::cout << "How would you like to display the information?\n";
        std::cout << "1. Print to terminal\n";
        std::cout << "2. Write to an output file\n";
        std::cout << "Your choice: ";
        std::cin >> display_option;

        if (display_option == 1) {
            std::cout << "Spells with effect: " << effect << "\n";
            for (int i = 0; i < spellbook_count; ++i) {
                for (int j = 0; j < spellbooks[i].num_spells; ++j) {
                    if (spellbooks[i].spells[j].effect == effect) {
                        std::cout << "- " << spellbooks[i].spells[j].name 
                                  << " (Success Rate: " 
                                  << spellbooks[i].spells[j].success_rate 
                                  << ")\n";
                    }
                }
            }
            break;
        } else if (display_option == 2) {
            std::string filename;
            std::cout << "Enter the output filename: ";
            std::cin >> filename;

            std::ofstream outfile(filename, std::ios::app);
            outfile << "Spells with effect: " << effect << "\n";
            for (int i = 0; i < spellbook_count; ++i) {
                for (int j = 0; j < spellbooks[i].num_spells; ++j) {
                    if (spellbooks[i].spells[j].effect == effect) {
                        outfile << "- " << spellbooks[i].spells[j].name 
                                << " (Success Rate: " 
                                << spellbooks[i].spells[j].success_rate << ")\n";
                    }
                }
            }
            outfile.close();
            std::cout << "Information written to " << filename << "\n";
            break;
        } else {
            std::cout << "Invalid option. Please enter 1 or 2.\n";
        }
    }
}