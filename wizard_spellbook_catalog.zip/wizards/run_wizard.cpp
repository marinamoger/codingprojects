#include "catalog.hpp"

void display_menu() {
    std::cout << "\n1. Display all spellbooks and spells\n"
              << "2. Search spellbook by name\n"
              << "3. Search spells by effect\n"
              << "4. Quit\n"
              << "Your Choice: ";
}

int main() {
	// TODO Complete the main() function (remember to keep it small for
	// modularity)
	int wizard_count, spellbook_count;
    std::string wizard_file, spellbook_file;

    std::cout << "Enter wizard filename: ";
    std::cin >> wizard_file;
    std::cout << "Enter spellbook filename: ";
    std::cin >> spellbook_file;

    wizard* wizards = read_wizards(wizard_file, wizard_count);
    spellbook* spellbooks = read_spellbooks(spellbook_file, spellbook_count);
    wizard* user = login(wizards, wizard_count);

    int choice;
    do {
        display_menu();
        std::cin >> choice;

        if (choice == 1) {
            display_all_spellbooks(spellbooks, spellbook_count, user);
        } else if (choice == 2) {
            search_spellbook_by_name(spellbooks, spellbook_count);
        } else if (choice == 3) {
            search_spells_by_effect(spellbooks, spellbook_count, user);
        } else if (choice == 4) {
            std::cout << "Goodbye!\n";
        } else {
            std::cout << "Invalid choice. Try again.\n";
        }
    } while (choice != 4);

delete_spellbooks(spellbooks, spellbook_count);
delete[] wizards;
return 0;
}