This was an assignment written for CS 162 � Introduction to Computer Science, taught in C++. 

I used file handling, data structures, modular programming, user input handling, and control flow to develop a wizard spellbook catalog system that reads and processes data from files, authenticates users, and allows searching for spellbooks and spells based on user input.

This program allows users to log in to a database of spells and spell books. Users can search for spells by name or effect and can choose to print the spells to the terminal or a text file. Available spells are restricted depending on the user's status.

How to run: 

When the program runs, it will ask the user to enter a wizard filename and a spellbook filename. The user must enter wizards.txt and spellbooks.txt, respectively. 

It will then ask the user for an ID and a password. These can be found in wizards.txt, and the user may choose who they want to be. 

Example: Ron_Weasley 588173 knightToH3 Student 0
	ID: 588173
	Password: knightToH3

The program then displays information about the user and give the option to pick between the following: 
1. Display all spellbooks and spells
2. Search spellbook by name
3. Search spells by effect
4. Quit

The user may choose what they want the program to do. Sometimes the actions will be restricted based on a user�s status. For example, students cannot access death or poison spells, but the Headmaster has access to all spells. 


