#include "battle.hpp"
#include <cmath>

//battle constructor 
 battle::battle(pokemon& trainer_1_pokemon, pokemon& trainer_2_pokemon)
        : trainer_1_pokemon(trainer_1_pokemon), 
        trainer_2_pokemon(trainer_2_pokemon), 
        player1_has_potion(true), player2_has_potion(true) {}


//main battle loop
    void battle::start_battle () {
        //while both players have more than 0 hp, alternate turns
        while (trainer_1_pokemon.get_hp() > 0 && trainer_2_pokemon.get_hp() > 0){
            //trainer 1's turn
            if (current_turn == 1) {
                std::cout << "It's Trainer 1's turn!" << std::endl;
                std::cout << "\n";
                std::cout << trainer_1_pokemon.get_name() << " HP: " 
                << trainer_1_pokemon.get_hp() << std::endl;
                std::cout << trainer_2_pokemon.get_name() << " HP: " 
                << trainer_2_pokemon.get_hp() << std::endl;
                player_turn(trainer_1_pokemon, trainer_2_pokemon, 
                player1_has_potion); //pass to the turn handling function
                current_turn = 2; //set to trainer 2's turn
            } else {
                //trainer 2's turn
                std::cout << "\nIt's Trainer 2's turn!" << std::endl;
                std::cout << "\n";
                std::cout << trainer_1_pokemon.get_name() << " HP: " 
                << trainer_1_pokemon.get_hp() << std::endl;
                std::cout << trainer_2_pokemon.get_name() << " HP: " 
                << trainer_2_pokemon.get_hp() << std::endl;
                player_turn(trainer_2_pokemon, trainer_1_pokemon, 
                player2_has_potion); //pass to the turn handling function
                current_turn = 1; //set to trainer 1's turn
            }
        }
        declare_winner(); //call declare winner function
    }

//function to handle each player's turn
void battle::player_turn(pokemon& attacker, pokemon& defender, bool& has_potion){
    int choice;
    //loop to ensure user enters a valid choice
    do{
    std::cout << "\nChoose an action: \n1. Attack \n2. Use a healing potion"
    << std::endl;
    std::cin >> choice;
    if (choice != 1 && choice != 2) {
            std::cout << "Invalid choice. Please enter 1 or 2.\n";
        }
    if (choice == 2 && !has_potion) {
            std::cout << "No potions left to use." <<
             "Please choose another action.\n";
            choice = -1;  // Invalidates choice to continue looping
        }
    } while (choice != 1 && choice != 2);
    //attack loop
    if (choice == 1){
        double type_interaction = 1.0;
        int attack_choice;
        do {
        std::cout << "\nChoose an attack move: " << std::endl;
        std::cout << "1. Scratch (" << attacker.get_move(0).get_num_of_uses() 
        << " uses remaining)" << std::endl;
        std::cout << "2. " << attacker.get_move(1).get_name() << "(" << 
        attacker.get_move(1).get_num_of_uses() << " uses remaining)" 
        << std::endl;
        std::cin >> attack_choice;
            //if scratch has uses left, use it on the opponent
            if (attack_choice == 1 && attacker.get_move(0).get_num_of_uses() > 0)
            {
                move chosen_move = attacker.get_move(0);
                int damage = calculate_damage(attacker, defender, chosen_move, 
                type_interaction);
                std::cout << "\n" << attacker.get_name() << " uses: " << 
                chosen_move.get_name() << "! It deals " << damage 
                << " damage points to " << defender.get_name() << "!" 
                << std::endl;

                //set new hp after damage
                defender.set_hp(defender.get_hp() - damage); 
                // decrement move uses
                attacker.get_move(0).decrement_num_of_uses();

                break;
            //if the unique move has uses left, use it on the opponent
            } else if (attack_choice == 2 && 
            attacker.get_move(1).get_num_of_uses() > 0) {
                move chosen_move = attacker.get_move(1);
                int damage = calculate_damage(attacker, defender, chosen_move, 
                type_interaction);
                std::cout << attacker.get_name() << " uses: " << 
                chosen_move.get_name() << "! It deals " << damage 
                << " damage points to " << defender.get_name() << "!" 
                << std::endl;

                //set new hp after damage
                defender.set_hp(defender.get_hp() - damage);
                // decrement move uses
                attacker.get_move(1).decrement_num_of_uses();  

                break; 
            } else {
                std::cout << "Selected move has no uses left or invalid choice." 
                << "Please choose another move.\n";
            }
            } while(true);
    } else if (choice == 2) {
        if (has_potion) {
            //healing potion
            int heal_amount = 10;
            int new_hp = attacker.get_hp() + heal_amount;

            //ensure hp doesn't exceed orginal hp
            if (new_hp > attacker.get_starting_hp()) {
                new_hp = attacker.get_starting_hp(); 
            }

            //set new hp and uses potion
            attacker.set_hp(new_hp);
            has_potion = false;

            std::cout << attacker.get_name() << " uses a healing potion and" <<
             "restores HP to " << new_hp << ".\n";
        } else {
            std::cout << "No potions left to use.\n";
        }
    } else {
        std::cout << "Invalid action choice.\n";
    }
    
};

 //function to calculate damage 
double battle::calculate_damage(pokemon& attacker, pokemon& defender, 
move& move, double type_interaction){
    // retrieve attack and defense stats
    double attack = static_cast<double>(attacker.get_attack());
    double defense = static_cast<double>(defender.get_defense());
    double base_damage = static_cast<double>(move.get_base_damage());

    // calculate random_multiplier as a random number between 0.8 and 1.2
    double random_multiplier = 0.8 + (static_cast<double>(rand()) / RAND_MAX) 
    * 0.4;
    std::cout << "Value of random_multiplier: " << random_multiplier 
    << std::endl;

    // calculate random_critical with a 10% chance to be 3, otherwise 1
    double random_critical = (rand() % 10 == 0) ? 3.0 : 1.0;// 10% chance to be 3
    std::cout << "Value of random_critical: " << random_critical << std::endl;

    // print the type_interaction value
    std::cout << "Value of type_interaction: " << type_interaction << std::endl;

    // calculate the damage using the provided formula
    double damage = (attack / defense) * type_interaction * base_damage * 
    random_multiplier * random_critical;
    damage = std::ceil(damage);  // round up to the nearest integer
    std::cout << "Value of damage: " << damage << " (after rounding up)" 
    << std::endl;
    std::cout << "\n";
    return static_cast<int>(damage);  // return damage as an integer
};

    //function to declare winner
    void battle::declare_winner() {
    if (trainer_1_pokemon.get_hp() > 0) {
        std::cout << "Trainer 1 wins! " << trainer_1_pokemon.get_name() 
        << " is victorious!\n";
    } else if (trainer_2_pokemon.get_hp() > 0) {
        std::cout << "Trainer 2 wins! " << trainer_2_pokemon.get_name() 
        << " is victorious!\n";
    } else {
        std::cout << "It's a draw! Both Pokémon are out of HP.\n";
    }
}