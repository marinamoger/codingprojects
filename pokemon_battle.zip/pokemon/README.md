This program was written for an assignment in CS 162 � Introduction to Computer Science, taught in C++. 

This program allows to players to battle Pokemon of their choice. The players take turns using healing potions or attacking with unique moves until one of the Pokemon runs out of HP.

