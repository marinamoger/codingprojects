#ifndef POKEMON_HPP
#define POKEMON_HPP

#include "move.hpp"

class pokemon {
private:
	//pokemon attributes
	std::string name;
	std::string type;
	int starting_hp;
	int current_hp;
	int attack;
	int defense;
	move* move_arr; //dynamic array of moves
	int num_moves;
	
public:
	/*  Constructor to initialize pokemon object with name, type, starting hp, 
	 *	current hp, attack value, and defense value
	 */
	pokemon(const std::string& name, const std::string type, int hp, int attack, 
	int defense);

	//destructor to free memory
	~pokemon();

	//getters for each part of the constructor
	std::string get_name() const; 
	int get_hp() const;
	std::string get_type() const;
	int get_attack() const;
	int get_defense() const;
	move& get_move(int index);
	const move& get_move(int index) const;
	int get_starting_hp() const;
	
	//setter for hp
	void set_hp(int hp);
};

#endif
