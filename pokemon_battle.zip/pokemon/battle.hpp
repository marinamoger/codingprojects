#ifndef BATTLE_HPP
#define BATTLE_HPP

#include "pokemon.hpp"

class battle {
private:
    //initialize two pokemon objects
    pokemon trainer_1_pokemon;
    pokemon trainer_2_pokemon;

    //variable to keep track of turns
    int current_turn = 1;

    //bools to see if player has a healing potion or not
    bool player1_has_potion = true;
    bool player2_has_potion = true;
    
public:
    //constructor to initialize battle and set starting conditions 
    battle(pokemon& trainer_1_pokemon, pokemon& trainer_2_pokemon);

    //function to start battle
    void start_battle();

    //function to handle player selection each turn
    void player_turn(pokemon& attacker, pokemon& defender, bool& has_potion);

    //function to calculate damage 
    double calculate_damage(pokemon& attacker, pokemon& defender, move& move, 
    double type_interaction);

    //function to declare winner
    void declare_winner();

   
};

#endif
