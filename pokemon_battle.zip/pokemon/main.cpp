#include "startup.hpp"
#include "pokemon.hpp"
#include "battle.hpp"
/*
 * Author: Marina Moger
 * Program Description: This program allows to players to battle Pokemon of 
 * their choice. The players take turns using healing potions or attacking 
 * with unique moves until one of the Pokemon runs out of HP. 
 */
int main() {
	//starter code: don't touch
	int trainer_1_pokemon_choice = prompt_first_pokemon();
	int trainer_2_pokemon_choice = prompt_second_pokemon(
		trainer_1_pokemon_choice
	);

	//initalize empty pokemon
	pokemon* trainer_1_pokemon = nullptr;;
	pokemon* trainer_2_pokemon = nullptr;

	//assign pokemon name, type, hp, attack, & defense based on user choice
	if (trainer_1_pokemon_choice == 1) {
		trainer_1_pokemon = new pokemon("Charmander", "Fire", 18, 6, 4);
	} else if (trainer_1_pokemon_choice == 2) {
		trainer_1_pokemon = new pokemon("Squirtle", "Water", 22, 4, 6);
	} else if (trainer_1_pokemon_choice == 3) {
		trainer_1_pokemon = new pokemon("Bulbasaur", "Grass", 20, 5, 5);
	}

	if (trainer_2_pokemon_choice == 1) {
		trainer_2_pokemon = new pokemon("Charmander", "Fire", 18, 6, 4);
	} else if (trainer_2_pokemon_choice == 2) {
		trainer_2_pokemon = new pokemon("Squirtle", "Water", 22, 4, 6);
	} else if (trainer_2_pokemon_choice == 3) {
		trainer_2_pokemon = new pokemon("Bulbasaur", "Grass", 20, 5, 5);
	}

	//pass in pokemon's info of users' choice
	battle battle(*trainer_1_pokemon, *trainer_2_pokemon);

	//begin the main battle loop
	battle.start_battle();

	//free allocated memory
	delete trainer_1_pokemon;
    delete trainer_2_pokemon;

	return 0;
}
