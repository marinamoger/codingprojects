#include "linked_list.hpp"
#include "node.hpp"
#include <iostream>

//copy constructor
linked_list::linked_list(const linked_list& other) {
	// initialize to default empty 
    head = nullptr;
    length = 0;

    // copy all nodes from the other list
    node* current = other.head;
    while (current != nullptr) {
        push_back(current->val);
        current = current->next;
    }
}

//AOO
void linked_list::operator=(const linked_list& other) {
	if (this == &other) return;

    clear(); // clear existing nodes

    // copy all nodes from the other list
    node* current = other.head;
    while (current != nullptr) {
        push_back(current->val);
        current = current->next;
    }
}

//destructor
linked_list::~linked_list() {
	clear(); 
}

//returns length of list
int linked_list::get_length() {
	return length;
}

//prints all values in the list
void linked_list::print() {
	node* current = head;
    while (current != nullptr) {
        std::cout << current->val << " ";
        current = current->next;
    }
    std::cout << std::endl;
}

//removes all nodes from the list
void linked_list::clear() {
	while (head != nullptr) {
        pop_front();
    }
}

//inserts a new value at the front of the list
void linked_list::push_front(int value) {
	node* new_node = new node(value);
    new_node->next = head;
    head = new_node;
    length++;
}

//inserts new value at the end of the list
void linked_list::push_back(int value) {
	node* new_node = new node(value);
    if (head == nullptr) {
        head = new_node;
    } else {
        node* current = head;
        while (current->next != nullptr) {
            current = current->next;
        }
        current->next = new_node;
    }
    length++;
}

//inserts a value at a particular index
void linked_list::insert(int value, int index) {
	if (index < 0 || index > length) return; 

    if (index == 0) {
        push_front(value);
        return;
    }

    node* new_node = new node(value);
    node* current = head;

    for (int i = 0; i < index - 1; i++) {
        current = current->next;
    }

    new_node->next = current->next;
    current->next = new_node;
    length++;
}

//removes first node from the list
void linked_list::pop_front() {
	if (head == nullptr) return; // list is empty

    node* temp = head;
    head = head->next;
    delete temp;
    length--;
}

//removes last node from the list
void linked_list::pop_back() {
	if (head == nullptr) return; // list is empty

    if (head->next == nullptr) {
        delete head;
        head = nullptr;
    } else {
        node* current = head;
        while (current->next->next != nullptr) {
            current = current->next;
        }
        delete current->next;
        current->next = nullptr;
    }
    length--;
}

//removes node from a particular index
void linked_list::remove(int index) {
	if (index < 0 || index >= length) return; 

    if (index == 0) {
        pop_front();
        return;
    }

    node* current = head;

    for (int i = 0; i < index - 1; i++) {
        current = current->next;
    }

    node* temp = current->next;
    current->next = temp->next;
    delete temp;
    length--;
}

//sort the list in ascending order
void linked_list::sort_ascending() {
    // already sorted or empty list
	if (head == nullptr || head->next == nullptr) return; 

    // use recursive merge sort
    head = merge_sort(head, true);
}

//sort the list in decending order
void linked_list::sort_descending() {
    // already sorted or empty list
	if (head == nullptr || head->next == nullptr) return; 

    // use recursive merge sort
    head = merge_sort(head, false);
}

// helper function for merge sort
node* linked_list::merge_sort(node* head, bool ascending) {
    if (head == nullptr || head->next == nullptr) return head;

    // split the list into two halves
    node* middle = get_middle(head);
    node* second_half = middle->next;
    middle->next = nullptr;

    // recursively sort both halves
    node* left = merge_sort(head, ascending);
    node* right = merge_sort(second_half, ascending);

    // merge the two sorted halves
    return merge(left, right, ascending);
}

// helper function to find the middle of the list
node* linked_list::get_middle(node* head) {
    node* slow = head;
    node* fast = head->next;

    while (fast != nullptr && fast->next != nullptr) {
        slow = slow->next;
        fast = fast->next->next;
    }

    return slow;
}

// helper function to merge two sorted lists
node* linked_list::merge(node* left, node* right, bool ascending) {
    if (left == nullptr) return right;
    if (right == nullptr) return left;

    node* result;

    if ((ascending && left->val <= right->val) ||
        (!ascending && left->val > right->val)) {
        result = left;
        result->next = merge(left->next, right, ascending);
    } else {
        result = right;
        result->next = merge(left, right->next, ascending);
    }

    return result;
}