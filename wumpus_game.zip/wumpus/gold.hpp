#ifndef GOLD_HPP
#define GOLD_HPP

#include "event.hpp"
#include <iostream>

class Gold : public Event {
public:
    // Constructor
    Gold();

    // Destructor
    ~Gold();

    // Percept function: displays the percept message when near gold
    void percept() const override;

    // Encounter function: handles logic when the player finds the gold
    bool encounter() override;

    char get_debug_symbol() const override; // Returns 'G'
};



#endif
