#include "wumpus.hpp"
#include <iostream>
#include <cstdlib> // for rand()

// TODO Wumpus implementation (define wumpus member functions below)

//Constructor to initialize the Wumpus as alive
wumpus::wumpus() : alive(true), row(-1), col(-1) {}

//Destructor to destroy Wumpus object
wumpus::~wumpus() {}

void wumpus::set_position(int new_row, int new_col) {
    row = new_row;
    col = new_col;
}

/* Function: percept 
   Description: displays the message when the adventurer is adjacent to the 
   Wumpus. 
*/
void wumpus::percept() const {
    std::cout << "The hairs stand up on the back of your neck." << std::endl;
}

/* Function: encounter
   Description: defines what happenes when the adventurer enters the same 
   room as the Wumpus.
   Return (bool): whether or not the Wumpus continues to exist
*/
bool wumpus::encounter() {
        std::cout << "The Wumpus wakes up and eats you! Game over." << std::endl;
        return true; //game over
}

/* Function: hit_by_arrow
   Description: defines what happens when the Wumpus is hit by an arrow.
*/
void wumpus::hit_by_arrow() {
    alive = false;
}

/* Function: missed_by_arrow
   Description: defines what happens when the arrow misses the Wumpus.
*/
void wumpus::missed_by_arrow(int width, int height) {
    std::cout << "The Wumpus has been startled and moves to a random room!" << std::endl;

    int new_row, new_col;
    do {
        new_row = rand() % height;
        new_col = rand() % width;
    } while (new_row == row && new_col == col); // Ensure Wumpus moves to a new position

    // Update the Wumpus's internal position
    this->row = new_row;
    this->col = new_col;
}

char wumpus::get_debug_symbol() const {
    return 'W'; // Debug symbol for Wumpus
}

bool wumpus::is_alive() const {
    return alive;
}

int wumpus::get_row() const {
    return row;
}

int wumpus::get_col() const {
    return col;
}
