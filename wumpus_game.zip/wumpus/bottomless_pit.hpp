#ifndef BOTTOMLESS_PIT_HPP
#define BOTTOMLESS_PIT_HPP
#include "event.hpp"
#include <iostream>
#include <cstdlib> // for random chance

class BottomlessPit : public Event {
public:
    // Constructor
    BottomlessPit();

    // Destructor
    ~BottomlessPit();

    // Percept function: displays a message when near the pit
    void percept() const override;

    // Encounter function: defines logic when the player falls into the pit
    bool encounter() override;

    char get_debug_symbol() const override; // Returns 'P'
};

#endif



