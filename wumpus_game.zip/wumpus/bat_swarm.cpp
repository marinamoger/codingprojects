#include "bat_swarm.hpp"

// Constructor
BatSwarm::BatSwarm() {}

// Destructor
BatSwarm::~BatSwarm() {}

// Percept: Notify the player about flapping sounds
void BatSwarm::percept() const {
    std::cout << "You hear screeching." << std::endl;
}

// Encounter: Player encounters bats and gets moved to a random room
bool BatSwarm::encounter() {
    std::cout << "A swarm of bats picks you up and drops you in a random room!" << std::endl;
    return true; // Game continues
}

char BatSwarm::get_debug_symbol() const {
    return 'B'; // Debug symbol for Bat Swarm
}