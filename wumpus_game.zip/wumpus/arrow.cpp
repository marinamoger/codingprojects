#include "arrow.hpp"

// Constructor
Arrow::Arrow() {}

// Destructor
Arrow::~Arrow() {}

// Percept: no percept for arrows
void Arrow::percept() const {
    // No percept message for arrows
}

// Encounter: Player picks up an arrow
bool Arrow::encounter() {
    std::cout << "You found an arrow!" 
    << std::endl;
    return true; // Game continues
}

char Arrow::get_debug_symbol() const {
    return 'A'; // Debug symbol for Arrow
}