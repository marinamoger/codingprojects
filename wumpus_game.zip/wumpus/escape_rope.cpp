#include "escape_rope.hpp"
#include <iostream>
#include "event.hpp"
// Constructor
EscapeRope::EscapeRope() {}

// Destructor
EscapeRope::~EscapeRope() {}

// Percept: no percept for escape rope
void EscapeRope::percept() const {
    // No percept message for the escape rope
}

// Encounter: player finds the escape rope
bool EscapeRope::encounter() {
    std::cout << "You found the escape rope! Return here to win the game." 
    << std::endl;
    return true; // Game continues
}

char EscapeRope::get_debug_symbol() const {
    return 'E'; // Debug symbol for Escape Rope
}
