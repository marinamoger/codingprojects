#include "gold.hpp"

// Constructor
Gold::Gold() {}

// Destructor
Gold::~Gold() {}

// Percept: Notify the player that they are near gold
void Gold::percept() const {
    std::cout << "You stub your toe on something shiny." << std::endl;
}

// Encounter: Player finds the gold
bool Gold::encounter() {
    std::cout << "You found the gold!" << std::endl;
    return true; // Indicate that the game continues after finding the gold
}

char Gold::get_debug_symbol() const {
    return 'G'; // Debug symbol for Gold
}