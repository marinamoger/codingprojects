#include "bottomless_pit.hpp"

// Constructor
BottomlessPit::BottomlessPit() {}

// Destructor
BottomlessPit::~BottomlessPit() {}

// Percept: Notify the player about a breeze nearby
void BottomlessPit::percept() const {
    std::cout << "You feel a breeze." << std::endl;
}

// Encounter: Player falls into the pit with a 50% chance
bool BottomlessPit::encounter() {
    if (rand() % 2 == 0) { // 50% chance
        std::cout << "You fell into a bottomless pit! Game over." << std::endl;
        return false; // End the game
    } else {
        std::cout << "You barely escape the pit!" << std::endl;
        return true; // Game continues
    }
}

char BottomlessPit::get_debug_symbol() const {
    return 'P'; // Debug symbol for Bottomless Pit
}