This program was written for an assignment in CS 162 - Introduction to Computer 
Science, taught in C++. 

This program demonstrates object-oriented programming, file handling, 
modular design, game logic implementation, and memory management to create an 
interactive Wumpus game using multiple C++ classes, structured header and source 
files, and a Makefile for compilation.

This program allows a user to navigate the Wumpus' cave and hunt for
gold and escape using a rope, or kill the Wumpus with an arrow, all while 
navigating obstacles like bat swarms and bottomless pits. 

The user may choose to play in debug mode, which shows where each of the game
elements are on the board. If the user chooses to play in normal mode, the elements
are hidden and the user must navigate around the board using the percepts that
appear when they are near an object.

