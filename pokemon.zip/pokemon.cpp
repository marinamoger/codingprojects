#include "pokemon.hpp"
#include "startup.hpp"
#include "move.hpp"
#include <algorithm>

//constructor for pokemon objects and their attributes
pokemon::pokemon(const std::string& name, const std::string type, int hp, 
int attack, int defense) : 
	name(name), type(type), starting_hp(hp), current_hp(hp), attack(attack), 
	defense(defense), num_moves(2) {

        //dynamic array of moves
        move_arr = new move[num_moves];

        //initialize scratch as the first move for all pokemon
        move_arr[0].set_name("Scratch");
        move_arr[0].set_type("Normal");
        move_arr[0].set_base_damage(3);
        move_arr[0].set_num_uses(10000);

        //initialize pokemon's second move based on its name
        if (name == "Charmander") {
            move_arr[1].set_name("Ember");
            move_arr[1].set_type("Fire");
            move_arr[1].set_base_damage(5);
            move_arr[1].set_num_uses(3);
        } else if (name == "Squirtle") {
            move_arr[1].set_name("Water Gun");
            move_arr[1].set_type("Water");
            move_arr[1].set_base_damage(5);
            move_arr[1].set_num_uses(3);
        } else if (name == "Bulbasaur") {
            move_arr[1].set_name("Vine Whip");
            move_arr[1].set_type("Water");
            move_arr[1].set_base_damage(5);
            move_arr[1].set_num_uses(3);
        }
    };

// destructor to deallocate the moves array
pokemon::~pokemon() {
    delete[] move_arr;
}

//getters for each of the pokemon attributes
std::string pokemon::get_name() const {
    return name;
    }

int pokemon::get_hp() const {
    return current_hp;
    }

std::string pokemon::get_type() const {
    return type;
    }

int pokemon::get_attack() const {
    return attack;
    }
    
int pokemon::get_defense() const {
    return defense;
    }

move& pokemon::get_move(int index) {
    return move_arr[index];
}

const move& pokemon::get_move(int index) const {
    return move_arr[index];
}

int pokemon::get_starting_hp() const {
    return starting_hp;
}

//function to prevent hp from exceeding its start value
void pokemon::set_hp(int hp) {
    if (hp > starting_hp) {
        current_hp = starting_hp;
    } else {
        current_hp = hp; 
    }
}



