// TODO Implement member functions of the move class

#include "move.hpp"

// setters for each of the move's attributes
void move::set_name(const std::string& move_name) {
    name = move_name;
}

void move::set_type(const std::string& move_type) {
    type = move_type;
}

void move::set_base_damage(int damage) {
    base_damage = damage;
}

void move::set_num_uses(int uses) {
    num_of_uses = uses;
}

//getters for each of the move's attributes
std::string move::get_name() const{
    return name;
}

std::string move::get_type() const{
    return type;
}

int move::get_base_damage() const{
    return base_damage;
}

int move::get_num_of_uses() const{
    return num_of_uses;
}

void move::decrement_num_of_uses() {
    if (num_of_uses > 0) {
        num_of_uses--;
    }
}