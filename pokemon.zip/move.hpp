#ifndef MOVE_HPP
#define MOVE_HPP

#include <iostream>

class move {
private:
	//move attributes
	std::string name;
	std::string type;
	int base_damage;
	int num_of_uses;
public:
	//setters for each attribute of the moves
	void set_name(const std::string& move_name);
	void set_type(const std::string& move_type);
	void set_base_damage(int damage);
	void set_num_uses(int uses);

	//getters for each attribute of the moves
	std::string get_name() const;
	std::string get_type() const;
	int get_base_damage() const;
	int get_num_of_uses() const;

	//function to decrement the number of moves after they've been used
	void decrement_num_of_uses();
};

#endif
