#ifndef NODE_HPP
#define NODE_HPP

struct node {
public:
	int val;	// the value that this node stores
	node* next;	// a pointer to the next node in the list

	// Default constructor
    node() : val(0), next(nullptr) {}

    // Parameterized constructor
    node(int val) : val(val), next(nullptr) {}

    // Destructor (optional, as we usually handle memory in the list class)
    ~node() = default;
};

#endif
