#ifndef ARROW_HPP
#define ARROW_HPP

#include "event.hpp"
#include <iostream>

class Arrow : public Event {
public:
    // Constructor
    Arrow();

    // Destructor
    ~Arrow();

    // Percept function: no percept for arrows
    void percept() const override;

    // Encounter function: logic for when the player picks up an arrow
    bool encounter() override;

    char get_debug_symbol() const override; // Returns 'A'
};

#endif
