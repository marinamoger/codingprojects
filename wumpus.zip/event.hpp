#ifndef EVENT_HPP
#define EVENT_HPP

// Event interface
class Event {
public:
    // Virtual destructor
    virtual ~Event() {}

    // Pure virtual function for percepts
    virtual void percept() const = 0;

    // Pure virtual function for encounters
    virtual bool encounter() = 0;

    virtual char get_debug_symbol() const = 0;

    virtual void missed_by_arrow(int width, int height) {}

    virtual void hit_by_arrow() {}
};


#endif
