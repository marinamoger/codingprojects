#include <iostream>
#include <algorithm>

#include "game.hpp"
#include "gold.hpp"
#include "bat_swarm.hpp"
#include "bottomless_pit.hpp"
#include "wumpus.hpp"
#include "escape_rope.hpp"
#include "arrow.hpp"

/*
 * Function: custom_shuffle
 * Description: shuffles events around the game board upon initialization
 */ 
template<typename T>
void custom_shuffle(std::vector<T>& vec) {
    for (size_t i = vec.size() - 1; i > 0; --i) {
        size_t j = rand() % (i + 1); // Generate a random index
        std::swap(vec[i], vec[j]);  // Swap the elements
    }
}

// game implementation
game::game(int width, int height, bool debug) :
	width(width),
	height(height),
	debug(debug) {

	//vector of rooms
	this->board = std::vector<std::vector<Room>>(height, 
    std::vector<Room>(width));
	
    //populate vector with events
	std::vector<Event*> events;
    	events.push_back(new wumpus());
    	events.push_back(new Gold());
    	events.push_back(new BatSwarm());
    	events.push_back(new BatSwarm());
    	events.push_back(new BottomlessPit());
    	events.push_back(new BottomlessPit());
    	events.push_back(new Arrow());
    	events.push_back(new Arrow());
    	events.push_back(new EscapeRope());
    
    //place the events in random rooms thorughout the board
	custom_shuffle(events);

    //loop that places events around the cave in a random fashion
	for (size_t i = 0; i < events.size(); ++i) {
        int row, col;
        do {
            row = rand() % height;
            col = rand() % width;
        } while (board[row][col].has_event()); // ensure the room is empty
        board[row][col].set_event(events[i]);

        // if the event is a Wumpus, set its initial position
        wumpus* w = dynamic_cast<wumpus*>(events[i]);
        if (w) {
            w->set_position(row, col);
        }
    }

    /* loop ensures player is placed in a room that does not already contain an 
     * event
     */
	do {
        this->player_row = rand() % height;
        this->player_col = rand() % width;
    } while (board[player_row][player_col].has_event());


}
 
/* Function: display_game
*  Description: Displays the game grid in the terminal
*/
void game::display_game() const{
	std::cout << std::endl << std::endl;
	std::cout << "Arrows remaining: " << this->num_arrows << std::endl;

	std::string row_border = "--";
	for (int i = 0; i <= this->width; ++i) {
		row_border += "-----";
	}

	std::cout << row_border << std::endl;
	for (int i = 0; i < this->height; ++i) {
		std::cout << "||";
		for (int j = 0; j < this->width; ++j) {
			// check if the player is in the current room
            if (i == this->player_row && j == this->player_col) {
                std::cout << "* "; // player's position
            } else {
                std::cout << "  "; // empty space
            }

            // Check if there is an event in the current room
            if (!this->debug || !board[i][j].has_event()) {
                std::cout << " "; // hidden event or no event
            } else {
                // print the event's debug symbol
                Event* event = board[i][j].get_event();
                if (event) {  // Ensure event is valid
                    std::cout << event->get_debug_symbol();
                }
            }
			std::cout << " ||";
		}
		std::cout << std::endl;
		std::cout << row_border << std::endl;
	}

	//example output (when finished): 
	// ----------------------
	// || P || G || P ||   ||
	// ----------------------
	// ||   || W ||   || S ||
	// ----------------------   
	// ||   ||   ||   || S ||
	// ----------------------   
	// ||*  ||   ||   ||   ||
	// ----------------------
}

 /*
 * Function: check_win
 * Description: Determines whether the player has won the game
 * Returns (bool): True if the player has won, false otherwise
 */
bool game::check_win() const {
    // check if the player has collected the gold and escaped
    if (has_gold && board[player_row][player_col].has_event()) {
        Event* event = board[player_row][player_col].get_event();
        if (dynamic_cast<EscapeRope*>(event)) {
            std::cout << "You escaped with the gold! You win!" << std::endl;
            return true;
        }
    }

    // check if the Wumpus is dead
    for (int i = 0; i < height; ++i) {
        for (int j = 0; j < width; ++j) {
            if (board[i][j].has_event()) {
                Event* event = board[i][j].get_event();
                wumpus* w = dynamic_cast<wumpus*>(event);
                if (w && !w->is_alive()) { 
                    std::cout << "You killed the Wumpus with an arrow! You win!" 
                    << std::endl;
                    return true;
                }
            }
        }
    }

    return false;
}

/*
 * Function: check_lose
 * Description: Determines whether the player has lost the game
 * Returns (bool): True if the player has lost, false otherwise
 */
bool game::check_lose() const {
    // check if the player encounters the Wumpus
    if (board[player_row][player_col].has_event()) {
        Event* event = board[player_row][player_col].get_event();
        wumpus* w = dynamic_cast<wumpus*>(event);
        if (w && w->is_alive()) {
            return true; // player loses
        }
    }
    // check if the player falls into a bottomless pit
    if (board[player_row][player_col].has_event()) {
        Event* event = board[player_row][player_col].get_event();
        BottomlessPit* pit = dynamic_cast<BottomlessPit*>(event);
        if (pit) {
            std::cout << "You fell into a bottomless pit! Game over." 
            << std::endl;
        }
    }
    // If no losing condition is met, return false
    return false;
}

/*
 * Function: Display Percepts
 * Description: Displays percepts based on the adventurer's location.
 */
void game::display_percepts() const {
    // Define the relative directions for cardinal neighbors
    int directions[4][2] = {
        {-1, 0}, // Up
        {1, 0},  // Down
        {0, -1}, // Left
        {0, 1}   // Right
    };

    // check all adjacent rooms for events
    for (int i = 0; i < 4; ++i) {
        int neighbor_row = player_row + directions[i][0];
        int neighbor_col = player_col + directions[i][1];

        // ensure the adjacent room is within bounds
        if (neighbor_row >= 0 && neighbor_row < height &&
            neighbor_col >= 0 && neighbor_col < width) {
            // check if the adjacent room has an event and display its percept
            if (board[neighbor_row][neighbor_col].has_event()) {
                board[neighbor_row][neighbor_col].get_event()->percept();
            }
        }
    }
}

/*
 * Function: is_direction
 * Description: Returns true if the given character is a valid direction
 * 		character (w/a/s/d) and false otherwise
 * Parameters:
 * 		c (char): The character to check
 * Returns (bool): Boolean indicating whether the character is a valid
 * 		direction character (w/a/s/d)
 */
bool game::is_direction(char c) {
	return c == 'w' ||
		c == 'a' ||
		c == 's' ||
		c == 'd';
}

/*
 * Function: to_lower
 * Description: Converts a given character to lowercase. Used to standardize
 * 		a user's character input.
 * Parameters:
 * 		direction (char): Character to convert to lowercase
 * Returns (char): Character converted to lowercase
 */
char game::to_lower(char direction) {
	if (direction >= 'A' && direction <= 'Z') {
		return direction + ('a' - 'A');
	}
	return direction;
}

/*
 * Function: can_move_in_direction
 * Description: Determines whether the player can move in the given
 * 		direction, based on their current location and the size of the
 * 		grid.
 * Parameters:
 * 		direction (char): Direction the player wishes to move in
 * Returns (bool): True if the player can move in the given direction
 * 		without moving off the grid. False otherwise.
 */
bool game::can_move_in_direction(char direction) {
    if (direction == 'w') {
        // Move up: check if player is not in the top row
        return player_row > 0;
    } else if (direction == 'a') {
        // Move left: check if player is not in the leftmost column
        return player_col > 0;
    } else if (direction == 's') {
        // Move down: check if player is not in the bottom row
        return player_row < height - 1;
    } else if (direction == 'd') {
        // Move right: check if player is not in the rightmost column
        return player_col < width - 1;
    } else {
        // Invalid direction
        return false;
    }
}

/*
 * Function: is_valid_action
 * Description: Determines whether the given action is valid.
 * Parameters:
 * 		action (char): Action the player wishes to perform.
 * Returns (bool): True if the requested action is valid. False otherwise.
 */
bool game::is_valid_action(char action) {
	if (this->is_direction(action)) {
		char direction = action;
		return this->can_move_in_direction(direction);
	} else if (action == 'f') {
		return this->num_arrows > 0;
	}
	return false;
}

/*
 * Function: print_action_error
 * Description: Prints a clear error message associated with the user's
 * 		provided invalid action
 * Parameters:
 * 		action (char): Invalid action that the user requested
 */
void game::print_action_error(char action) {
	if (this->is_direction(action)) {
		std::cout << "You can't move in that direction!" << std::endl <<
			std::endl;
	} else if (action == 'f') {
		std::cout << "You're out of arrows!" << std::endl << std::endl;
	} else {
		std::cout << std::endl << "That's an invalid input!" << std::endl
			<< std::endl;
	}
}

/*
 * Function: get_player_action
 * Description: Prompts the player for their action for the turn and
 * 		returns it as a char (w, a, s, d, or f). If the player enters
 * 		an invalid action, this function reprompts until a valid one is
 * 		provided.
 * Returns (char): The valid action provided by the player.
 */
char game::get_player_action() {
	char action;
	bool first = true;
	do {
		if (!first) {
			char previous_action = action;
			this->print_action_error(previous_action);
		}
		first = false;

		std::cout << std::endl << std::endl << "What would you like to do?" <<
			std::endl << std::endl;
		std::cout << "w: move up" << std::endl;
		std::cout << "a: move left" << std::endl;
		std::cout << "s: move down" << std::endl;
		std::cout << "d: move right" << std::endl;
		std::cout << "f: fire an arrow" << std::endl;

		std::cin >> action;
		action = this->to_lower(action);
	} while (!this->is_valid_action(action));

	return action;
}

/*
 * Function: get_arrow_fire_direction
 * Description: Prompts the player for the direction they want to fire an
 * 		arrow (w, a, s, or d) and returns it as a char. If the player enters
 * 		an invalid direction, this function reprompts until a valid one is
 * 		provided.
 * Returns (char): The valid direction provided by the player.
 */
char game::get_arrow_fire_direction() {
	char direction;
	bool first = true;
	do {
		if (!first) {
			std::cout << std::endl << "That's an invalid input!" <<
				std::endl << std::endl;
		}
		first = false;

		std::cout << std::endl << std::endl <<
			"What direction would you like to fire the arrow?" << std::endl <<
			std::endl;
		std::cout << "w: up" << std::endl;
		std::cout << "a: left" << std::endl;
		std::cout << "s: down" << std::endl;
		std::cout << "d: right" << std::endl;

		std::cin >> direction;
		direction = this->to_lower(direction);
	} while (!this->is_direction(direction));

	return direction;
}

/*
 * Function: move_up
 * Description: Moves the player up one grid space
 * Pre-condition: Player is capable of moving in this direction (without
 * 		hitting the edge of the board)
 * Post-condition: Player is moved accordingly.
 */
void game::move_up() {
	// Check if the player can move up
    if (player_row > 0) {
        // Update the player's position
        player_row -= 1;
    } else {
        std::cout << "You can't move up. There's a wall above you!" << std::endl;
    }
}

/*
 * Function: move_down
 * Description: Moves the player down one grid space
 * Pre-condition: Player is capable of moving in this direction (without
 * 		hitting the edge of the board)
 * Post-condition: Player is moved accordingly.
 */
void game::move_down() {
	// Check if the player can move down
    if (player_row < height - 1) {
        // Update the player's position
        player_row += 1;
    } else {
        std::cout << "You can't move down. There's a wall below you!" << std::endl;
    }
}

/*
 * Function: move_left
 * Description: Moves the player left one grid space
 * Pre-condition: Player is capable of moving in this direction (without
 * 		hitting the edge of the board)
 * Post-condition: Player is moved accordingly.
 */
void game::move_left() {
	 // Check if the player can move left
    if (player_col > 0) {
        // Update the player's position
        player_col -= 1;
    } else {
        std::cout << "You can't move left. There's a wall to your left!" << std::endl;
    }
}

/*
 * Function: move_right
 * Description: Moves the player right one grid space
 * Pre-condition: Player is capable of moving in this direction (without
 * 		hitting the edge of the board)
 * Post-condition: Player is moved accordingly.
 */
void game::move_right() {
	// Check if the player can move right
    if (player_col < width - 1) {
        // Update the player's position
        player_col += 1;
    } else {
        std::cout << "You can't move right. There's a wall to your right!" << std::endl;
    }
}

/*
 * Function: move
 * Description: Moves the player in the direction specified by the given
 * 		character
 * Parameters:
 * 		direction (char): Direction in which to move the player (a for
 * 			west, s for south, d for east, w for north).
 * Pre-condition: Player is capable of moving in this direction (without
 * 		hitting the edge of the board)
 * Post-condition: Player is moved accordingly.
 */
void game::move(char direction) {
	if (direction == 'w') {
		this->move_up();
	} else if (direction == 'a') {
		this->move_left();
	} else if (direction == 'd') {
		this->move_right();
	} else if (direction == 's') {
		this->move_down();
	} 
}

/*
 * Function: fire_arrow_up
 * Description: Fires an arrow upward
 * Post-condition: Arrow is fired upward. Wumpus is killed if hit / moves
 * 		if missed.
 */
void game::fire_arrow_up() {
	    // initialize arrow's position to the player's current location
    int arrow_row = player_row;
    int arrow_col = player_col;

    // move the arrow up to 3 spaces or until it goes out of bounds
    for (int i = 0; i < 3; ++i) {
        arrow_row--;

        // check if the arrow is out of bounds
        if (arrow_row < 0) {
            std::cout << "The arrow flew out of bounds." << std::endl;
            return;
        }

        // check if the arrow hits the Wumpus
        if (board[arrow_row][arrow_col].has_event()) {
    		Event* event = board[arrow_row][arrow_col].get_event();
    		event->hit_by_arrow(); 
    	return;
        }
    }

    // if the arrow doesn't hit the Wumpus, make it move
    std::cout << "The arrow missed. The Wumpus has moved to a new location!" 
    << std::endl;
    for (int i = 0; i < height; ++i) {
        for (int j = 0; j < width; ++j) {
            if (board[i][j].has_event()) {
                Event* event = board[i][j].get_event();
                wumpus* w = dynamic_cast<wumpus*>(event);
                    if (w) {
                    // Save the Wumpus's current position
                    int old_row = i;
                    int old_col = j;

                    // Call missed_by_arrow to update its internal position
                    w->missed_by_arrow(width, height);

                    // Get the Wumpus's new position
                    int new_row = w->get_row();
                    int new_col = w->get_col();

                    // Remove the Wumpus from its old room on the board
                    board[old_row][old_col].remove_event();

                    // Place the Wumpus in its new room on the board
                    board[new_row][new_col].set_event(w);

                    return; // Exit after moving the Wumpus
                    }
            }
        }
    }
}

/*
 * Function: fire_arrow_down
 * Description: Fires an arrow downward
 * Post-condition: Arrow is fired downward. Wumpus is killed if hit / moves
 * 		if missed.
 */
void game::fire_arrow_down() {
    // initialize arrow's position to the player's current location
    int arrow_row = player_row;
    int arrow_col = player_col;

    // move the arrow down up to 3 spaces or until it goes out of bounds
    for (int i = 0; i < 3; ++i) {
        arrow_row++;

        // check if the arrow is out of bounds
        if (arrow_row >= height) {
            std::cout << "The arrow flew out of bounds." << std::endl;
            return;
        }

        // check if the arrow hits the Wumpus
		if (board[arrow_row][arrow_col].has_event()) {
    		Event* event = board[arrow_row][arrow_col].get_event();
    		event->hit_by_arrow(); // Directly call the method
    		return;
        }
    }

    // if the arrow doesn't hit the Wumpus, make the Wumpus move
   std::cout << "The arrow missed. The Wumpus has moved to a new location!" 
   << std::endl;
		for (int i = 0; i < height; ++i) {
        for (int j = 0; j < width; ++j) {
            if (board[i][j].has_event()) {
                Event* event = board[i][j].get_event();
                wumpus* w = dynamic_cast<wumpus*>(event);
                    if (w) {
                    // save the Wumpus's current position
                    int old_row = i;
                    int old_col = j;

                    // call missed_by_arrow to update its internal position
                    w->missed_by_arrow(width, height);

                    // get the Wumpus's new position
                    int new_row = w->get_row();
                    int new_col = w->get_col();

                    // remove the Wumpus from its old room on the board
                    board[old_row][old_col].remove_event();

                    // place the Wumpus in its new room on the board
                    board[new_row][new_col].set_event(w);

                return; // exit after moving the Wumpus
            }
        }
    }
}
}

/*
 * Function: fire_arrow_left
 * Description: Fires an arrow leftward
 * Post-condition: Arrow is fired leftward. Wumpus is killed if hit / moves
 * 		if missed.
 */
void game::fire_arrow_left() {
    // initialize arrow's position to the player's current location
    int arrow_row = player_row;
    int arrow_col = player_col;

    // move the arrow left up to 3 spaces or until it goes out of bounds
    for (int i = 0; i < 3; ++i) {
        arrow_col--;

        // check if the arrow is out of bounds
        if (arrow_col < 0) {
            std::cout << "The arrow flew out of bounds." << std::endl;
            return;
        }

        // check if the arrow hits the Wumpus
        if (board[arrow_row][arrow_col].has_event()) {
            Event* event = board[arrow_row][arrow_col].get_event();
            event->hit_by_arrow(); // Directly call hit_by_arrow on the event
        return;
    }   
    }

    // If the arrow doesn't hit the Wumpus, make it move
    std::cout << "The arrow missed. The Wumpus has moved to a new location!" << std::endl;
    for (int i = 0; i < height; ++i) {
        for (int j = 0; j < width; ++j) {
            if (board[i][j].has_event()) {
                Event* event = board[i][j].get_event();
                wumpus* w = dynamic_cast<wumpus*>(event);
                    if (w) {
                    // Save the Wumpus's current position
                    int old_row = i;
                    int old_col = j;

                    // Call missed_by_arrow to update its internal position
                    w->missed_by_arrow(width, height);

                    // Get the Wumpus's new position
                    int new_row = w->get_row();
                    int new_col = w->get_col();

                    // Remove the Wumpus from its old room on the board
                    board[old_row][old_col].remove_event();

                    // Place the Wumpus in its new room on the board
                    board[new_row][new_col].set_event(w);

                return; // Exit after moving the Wumpus
            }
        }
    }
}
}

/*
 * Function: fire_arrow_right
 * Description: Fires an arrow rightward
 * Post-condition: Arrow is fired rightward. Wumpus is killed if hit / moves
 * 		if missed.
 */
void game::fire_arrow_right() {
    // Initialize arrow's position to the player's current location
    int arrow_row = player_row;
    int arrow_col = player_col;

    // Move the arrow right up to 3 spaces or until it goes out of bounds
    for (int i = 0; i < 3; ++i) {
        arrow_col++;

        // Check if the arrow is out of bounds
        if (arrow_col >= width) {
            std::cout << "The arrow flew out of bounds." << std::endl;
            return;
        }

        // Check if the arrow hits the Wumpus
        if (board[arrow_row][arrow_col].has_event()) {
            Event* event = board[arrow_row][arrow_col].get_event();
            if (event) {  // Ensure the event is valid
                event->hit_by_arrow();
                return;
            }
        }
    }

    // If the arrow doesn't hit the Wumpus, make it move
    std::cout << "The arrow missed. The Wumpus has moved to a new location!" << std::endl;
    for (int i = 0; i < height; ++i) {
        for (int j = 0; j < width; ++j) {
            if (board[i][j].has_event()) {
                Event* event = board[i][j].get_event();
                wumpus* w = dynamic_cast<wumpus*>(event);
                    if (w) {
                    // Save the Wumpus's current position
                    int old_row = i;
                    int old_col = j;

                    // Call missed_by_arrow to update its internal position
                    w->missed_by_arrow(width, height);

                    // Get the Wumpus's new position
                    int new_row = w->get_row();
                    int new_col = w->get_col();

                    // Remove the Wumpus from its old room on the board
                    board[old_row][old_col].remove_event();

                    // Place the Wumpus in its new room on the board
                    board[new_row][new_col].set_event(w);

                return; // Exit after moving the Wumpus
            }
        }
    }
}
}

/*
 * Function: fire_arrow
 * Description: Fires an arrow in the direction specified by the given
 * 		character
 * Parameters:
 * 		direction (char): Direction in which to fire arrow (a for
 * 			west, s for south, d for east, w for north).
 * Post-condition: Arrow is fired. Wumpus is killed if hit and moves if
 * 		missed.
 */
void game::fire_arrow(char direction) {
	if (direction == 'w') {
		this->fire_arrow_up();
	} else if (direction == 'a') {
		this->fire_arrow_left();
	} else if (direction == 's') {
		this->fire_arrow_right();
	} else {
		this->fire_arrow_down();
	}

	this->num_arrows--;
}

/*
 * Function: play_game
 * Description: Runs one full iteration of the game
 */
void game::play_game(){
	while (!this->check_win() && !this->check_lose()) {
		// Print game board
		this->display_game();

        //display percepts
		this->display_percepts();

		// ask player for their action
		char action = this->get_player_action();

		if (this->is_direction(action)) {
			char direction = action;
			this->move(direction);
		} else {
			char direction = this->get_arrow_fire_direction();
			this->fire_arrow(direction);
		}

	if (board[player_row][player_col].has_event()) {
    // Retrieve the event from the current room
    Event* event = board[player_row][player_col].get_event();

    // trigger the event's encounter logic
    if (!event->encounter()) {
        // If the encounter ends the game (e.g., falling into a pit or being 
        // eaten by the Wumpus), exit the game loop
        return;
    }

    // handle specific encounters 
    if (dynamic_cast<Arrow*>(event)) {
        std::cout << "You picked up an arrow!" << std::endl;
        num_arrows++;
        board[player_row][player_col].remove_event(); 
    } else if (dynamic_cast<Gold*>(event)) {
        std::cout << "You collected the gold!" << std::endl;
        has_gold = true; 
        board[player_row][player_col].remove_event(); 
    } else if (dynamic_cast<BatSwarm*>(event)) {
        // Move the player to a random room
        player_row = rand() % height;
        player_col = rand() % width;
    }
	}
	}
}

/* 
 * Function: Destructor
 * Description: ensures proper cleanup of dynamically allocated memory by 
 * iterating over the cave and removing any events present in each room
 */
game::~game() {
    for (int i = 0; i < height; ++i) {
        for (int j = 0; j < width; ++j) {
            if (board[i][j].has_event()) {
                board[i][j].remove_event();  // Free events
            }
        }
    }
}
