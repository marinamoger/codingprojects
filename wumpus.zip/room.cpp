#include "room.hpp"

// TODO Room implementation (define room member functions below)
// Constructor
Room::Room() : event(nullptr) {}

// Destructor
Room::~Room() {
    if (event) {
        delete event;
        event = nullptr;
    }
}

// Check if the room contains an event
bool Room::has_event() const {
    return event != nullptr;
}

// Set an event in the room
void Room::set_event(Event* new_event) {
    event = new_event;
}

// Get the event in the room
Event* Room::get_event() const {
    return event;
}

// Clear the event in the room
void Room::clear_event() {
    delete event; // free the event memory
    event = nullptr;
}

void Room::remove_event() {
    if (this->event) {
        delete this->event; // free the memory
        this->event = nullptr; // nullptr to prevent dangling access
    }
}