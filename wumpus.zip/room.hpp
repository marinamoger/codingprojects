#ifndef ROOM_HPP
#define ROOM_HPP

#include "event.hpp"

// Room interface
class Room {
private: 
	Event* event; // Pointer to an Event (polymorphic)
public:
	// Constructor
    Room();

    // Destructor
    ~Room();

    // Check if the room contains an event
    bool has_event() const;

    // Set an event in the room
    void set_event(Event* new_event);

    // Get the event in the room
    Event* get_event() const;

    // Clear the event in the room
    void clear_event();

    void remove_event(); // Removes the event from the room
};

#endif
