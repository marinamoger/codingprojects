#ifndef ESCAPE_ROPE_HPP
#define ESCAPE_ROPE_HPP
#include "event.hpp"
class EscapeRope : public Event {
public:
    // Constructor
    EscapeRope();

    // Destructor
    ~EscapeRope();

    // Percept function: no percept for escape rope
    void percept() const override;

    // Encounter function: defines logic when player finds the escape rope
    bool encounter() override;

    char get_debug_symbol() const override; // Returns 'E'
};


#endif
