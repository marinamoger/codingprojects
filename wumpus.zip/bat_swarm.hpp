#ifndef BAT_SWARM_HPP
#define BAT_SWARM_HPP

#include "event.hpp"
#include <iostream>
#include <cstdlib> // for random movement

class BatSwarm : public Event {
public:
    // Constructor
    BatSwarm();

    // Destructor
    ~BatSwarm();

    // Percept function: displays a message when near bats
    void percept() const override;

    // Encounter function: defines logic when the player encounters bats
    bool encounter() override;

    char get_debug_symbol() const override; // Returns 'B'
};


#endif
