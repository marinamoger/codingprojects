#ifndef WUMPUS_HPP
#define WUMPUS_HPP

#include "event.hpp"
#include <string>

class wumpus : public Event {
    private: 
    bool alive; //tracks whether wumpus is still alive
    int row; // wumpus's current row position
    int col; // wumpus's current column position

    public: 
    //Constructor to initialize the Wumpus object
    wumpus(); 

    //Destructor to destroy Wumpus object
    ~wumpus();

    /*  Function: percept 
        Description: displays the message when the adventurer is adjacent to the 
        Wumpus. 
    */
    void percept() const override;

    /*  Function: encounter
        Description: defines what happenes when the adventurer enters the same 
        room as the Wumpus.
        Return (bool): whether or not the Wumpus continues to exist
    */
    bool encounter() override;

    /*  Function: hit_by_arrow
        Description: defines what happens when the Wumpus is hit by an arrow.
    */
    void hit_by_arrow() override;

    /*  Function: missed_by_arrow
        Description: defines what happens when the arrow misses the Wumpus
    */
    void missed_by_arrow(int width, int height) override;

    /*
    * Function: get_debug_symbol
    * Description: Returns the debug symbol representing the Wumpus.
    * Return (char): 'W' to indicate the presence of the Wumpus.
    */
    char get_debug_symbol() const override; 

    /*
    * Function: is_alive
    * Description: Checks whether the Wumpus is still alive.
    * Return (bool): True if the Wumpus is alive, false otherwise.
    */
    bool is_alive() const; // Returns the status of the Wumpus

    /*
    * Function: set_position
    * Description: Sets the Wumpus's position on the game board.
    * Parameters:
    *    - row (int): The row index where the Wumpus is positioned.
    *    - col (int): The column index where the Wumpus is positioned.
    * Return (void): None.
    */
    void set_position(int row, int col); // Set the Wumpus's position

    /*
    * Function: get_row
    * Description: Retrieves the current row position of the Wumpus.
    * Return (int): The row index of the Wumpus.
    */
    int get_row() const;

    /*
    * Function: get_col
    * Description: Retrieves the current column position of the Wumpus.
    * Return (int): The column index of the Wumpus.
    */
    int get_col() const;
    
};

#endif
